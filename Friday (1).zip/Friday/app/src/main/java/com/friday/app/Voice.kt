package com.friday.app
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import java.util.Locale

/** Speech in/out. Prefers on-device recognition so nothing leaves the phone. */
class Voice(private val ctx: Context, private val onHeard: (String) -> Unit) {
    private var ready = false
    private val tts = TextToSpeech(ctx) { ready = it == TextToSpeech.SUCCESS; if (ready) tts0().language = Locale.getDefault() }
    private fun tts0() = tts
    private val sr = SpeechRecognizer.createSpeechRecognizer(ctx)

    fun speak(t: String) { if (ready) tts.speak(t, TextToSpeech.QUEUE_ADD, null, "f") }

    fun listen() {
        sr.setRecognitionListener(object : RecognitionListener {
            override fun onResults(r: Bundle) { r.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let(onHeard) }
            override fun onReadyForSpeech(p: Bundle?) {}; override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}; override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}; override fun onError(e: Int) {}
            override fun onPartialResults(p: Bundle?) {}; override fun onEvent(t: Int, p: Bundle?) {}
        })
        sr.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
        })
    }
    fun stop() { sr.destroy(); tts.shutdown() }
}
