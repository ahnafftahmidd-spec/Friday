package com.friday.app
import android.Manifest
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private lateinit var voice: Voice
    private lateinit var brain: Brain
    private lateinit var agent: Agent
    private lateinit var log: TextView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
        brain = Brain(this)
        val say = { t: String -> runOnUiThread { log.append("Friday: $t\n\n") }; voice.speak(t) }
        agent = Agent(this, brain, say)
        voice = Voice(this) { heard -> log.append("You: $heard\n"); Thread { agent.run(heard) }.start() }

        val purple = 0xFFC96BE6.toInt()
        log = TextView(this).apply { setTextColor(Color.WHITE); textSize = 16f; setPadding(40, 40, 40, 40) }
        val mic = Button(this).apply { text = "Talk to Friday"; setBackgroundColor(purple); setTextColor(Color.WHITE); setOnClickListener { voice.listen() } }
        val acc = Button(this).apply { text = "Enable phone control"; setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) } }
        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(0xFF111014.toInt()); gravity = Gravity.BOTTOM
            addView(ScrollView(this@MainActivity).apply { addView(log) }, LinearLayout.LayoutParams(-1, 0, 1f))
            addView(acc); addView(mic)
        })
        if (!brain.available) log.text = "Copy qwen.task to:\nAndroid/data/com.friday.app/files/\n\n"
    }
    override fun onDestroy() { voice.stop(); super.onDestroy() }
}
