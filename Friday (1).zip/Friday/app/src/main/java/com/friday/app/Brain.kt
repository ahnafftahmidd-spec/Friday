package com.friday.app
import android.content.Context
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import java.io.File

/**
 * Local Qwen. Put the converted model at:
 *   /sdcard/Android/data/com.friday.app/files/qwen.task
 * (Qwen2.5-3B-Instruct int4 converted to MediaPipe .task; swap for Qwen3-4B once converted.)
 */
class Brain(ctx: Context) {
    private val model = File(ctx.getExternalFilesDir(null), "qwen.task")
    val available get() = model.exists()
    private val llm: LlmInference? by lazy {
        if (!available) null else LlmInference.createFromOptions(ctx,
            LlmInference.LlmInferenceOptions.builder()
                .setModelPath(model.absolutePath).setMaxTokens(768).build())
    }
    // ChatML format used by Qwen
    fun chat(system: String, user: String): String =
        llm?.generateResponse("<|im_start|>system\n$system<|im_end|>\n<|im_start|>user\n$user<|im_end|>\n<|im_start|>assistant\n")
            ?: "Model not found. Copy qwen.task into my files folder."
}
