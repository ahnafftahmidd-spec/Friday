# Friday
Local Qwen 3B on-device phone agent with voice. Open in Android Studio and Run.
1. Get Qwen2.5-3B-Instruct (int4) as a MediaPipe .task file, name it qwen.task, put it in Android/data/com.friday.app/files/
2. Launch Friday, tap "Enable phone control" and turn on Friday in Accessibility.
3. Tap Talk to Friday and say e.g. "open Settings".

## Build without a computer
Upload this folder to a GitHub repo (github.com/new, "uploading an existing file"). The Actions tab builds app-debug.apk automatically; download it from the run's Artifacts and install it.
