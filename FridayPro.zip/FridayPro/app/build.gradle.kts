plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.friday.app"
    compileSdk = 34
    defaultConfig { applicationId = "com.friday.app"; minSdk = 28; targetSdk = 34; versionCode = 1; versionName = "0.1" }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
    androidResources { noCompress += "task" }
}
dependencies {
    implementation("com.google.mediapipe:tasks-genai:0.10.24") // on-device LLM runtime
}
