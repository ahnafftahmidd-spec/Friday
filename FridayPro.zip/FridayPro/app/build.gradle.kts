plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.friday.app"
    compileSdk = 35
    defaultConfig { applicationId = "com.friday.app"; minSdk = 28; targetSdk = 34; versionCode = 3; versionName = "0.4" }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    androidResources { noCompress += "task" }
    packaging { jniLibs { pickFirsts += "**/*.so" } }
}
kotlin {
    compilerOptions {
        jvmTarget.set(org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17)
        freeCompilerArgs.add("-Xskip-metadata-version-check")
    }
}
dependencies {
    implementation("com.google.mediapipe:tasks-genai:0.10.24")
    implementation("com.google.mlkit:text-recognition:16.0.1")
    implementation("com.google.mlkit:image-labeling:17.0.9")
    implementation("com.google.ai.edge.litertlm:litertlm-android:0.18.0") // runs the bigger Qwen3 4B
}
