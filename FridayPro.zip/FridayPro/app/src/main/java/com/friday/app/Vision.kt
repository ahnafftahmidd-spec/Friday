package com.friday.app
import android.graphics.Bitmap
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.label.ImageLabeling
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

/** On-device OCR + object labels. Call only from a background thread. */
object Vision {
    fun analyze(bmp: Bitmap): String {
        val img = InputImage.fromBitmap(bmp, 0)
        val text = try { Tasks.await(TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS).process(img)).text } catch (e: Exception) { "" }
        val labels = try {
            Tasks.await(ImageLabeling.getClient(ImageLabelerOptions.DEFAULT_OPTIONS).process(img))
                .filter { it.confidence > 0.6f }.take(6).joinToString { it.text }
        } catch (e: Exception) { "" }
        return "Objects: ${labels.ifEmpty { "none" }}. Text: ${text.replace("\n", " ").take(500).ifEmpty { "none" }}"
    }

    /** Text lines with tap coordinates, for screens the accessibility tree can't read. */
    fun lines(bmp: Bitmap): String {
        return try {
            val r = Tasks.await(TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS).process(InputImage.fromBitmap(bmp, 0)))
            r.textBlocks.flatMap { it.lines }.mapNotNull { l -> l.boundingBox?.let { "${l.text} @${it.centerX()},${it.centerY()}" } }
                .joinToString("\n").take(1200)
        } catch (e: Exception) { "" }
    }
}
