package com.friday.app
import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Long-term notes ("remember that...") and saved chat history. */
class Mem(ctx: Context) {
    private val p = ctx.getSharedPreferences("mem", 0)
    private fun arr(k: String): JSONArray = try { JSONArray(p.getString(k, "[]")) } catch (e: Exception) { JSONArray() }
    private fun save(k: String, l: List<String>) { p.edit().putString(k, JSONArray(l).toString()).apply() }

    @Synchronized fun notes(): List<String> { val a = arr("notes"); return (0 until a.length()).map { a.getString(it) } }
    @Synchronized fun add(n: String) { save("notes", (notes() + n.trim()).takeLast(60)) }
    @Synchronized fun remove(i: Int) { val l = notes().toMutableList(); if (i in l.indices) { l.removeAt(i); save("notes", l) } }
    @Synchronized fun forget(q: String): Int { val l = notes(); val k = l.filter { !it.contains(q, true) }; save("notes", k); return l.size - k.size }
    @Synchronized fun clearNotes() { save("notes", emptyList()) }

    @Synchronized fun log(user: Boolean, t: String) {
        val a = arr("log"); a.put(JSONObject().put("u", user).put("t", t))
        val l = (0 until a.length()).map { a.getJSONObject(it) }.takeLast(60)
        p.edit().putString("log", JSONArray(l).toString()).apply()
    }
    @Synchronized fun recent(n: Int): List<Pair<Boolean, String>> {
        val a = arr("log")
        return (0 until a.length()).map { a.getJSONObject(it) }.map { it.optBoolean("u") to it.optString("t") }.takeLast(n)
    }
    @Synchronized fun clearLog() { p.edit().putString("log", "[]").apply() }
}
