package com.friday.app
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

fun recognizerIntent(): Intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
    putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
}

/** One-shot listening for the mic button. */
object Ears {
    fun once(ctx: Context, onText: (String) -> Unit, onEnd: () -> Unit) {
        Core.pauseWake?.invoke()
        Core.micBusy = true
        val sr = SpeechRecognizer.createSpeechRecognizer(ctx)
        var ended = false
        fun finish() { if (ended) return; ended = true; Core.micBusy = false; sr.destroy(); onEnd() }
        sr.setRecognitionListener(object : RecognitionListener {
            override fun onResults(r: Bundle) { r.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let(onText); finish() }
            override fun onError(e: Int) { finish() }
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(p: Bundle?) {}
            override fun onEvent(t: Int, p: Bundle?) {}
        })
        sr.startListening(recognizerIntent())
    }
}
