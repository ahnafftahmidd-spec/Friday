package com.friday.app
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLDecoder
import java.net.URLEncoder

object Net {
    class Hit(val title: String, val snippet: String, val url: String)

    private fun get(u: String): String? {
        try {
            val c = URL(u).openConnection() as HttpURLConnection
            c.connectTimeout = 10000; c.readTimeout = 12000
            c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36")
            if (c.responseCode != 200) return null
            return c.inputStream.bufferedReader().use { it.readText().take(300_000) }
        } catch (e: Exception) { return null }
    }

    private fun clean(s: String): String = s.replace(Regex("<[^>]+>"), "")
        .replace("&amp;", "&").replace("&quot;", "\"").replace("&#x27;", "'").replace("&#39;", "'")
        .replace("&lt;", "<").replace("&gt;", ">").replace("&nbsp;", " ").replace(Regex("\\s+"), " ").trim()

    private fun realUrl(h: String): String {
        val m = Regex("uddg=([^&]+)").find(h)
        return if (m != null) URLDecoder.decode(m.groupValues[1], "UTF-8") else (if (h.startsWith("//")) "https:$h" else h)
    }

    fun search(q: String): List<Hit>? {
        val enc = URLEncoder.encode(q, "UTF-8")
        val html = get("https://html.duckduckgo.com/html/?q=$enc")
        if (html != null) {
            val a = Regex("class=\"result__a\"[^>]*href=\"([^\"]+)\"[^>]*>(.*?)</a>", RegexOption.DOT_MATCHES_ALL).findAll(html).toList()
            val s = Regex("class=\"result__snippet\"[^>]*>(.*?)</a>", RegexOption.DOT_MATCHES_ALL).findAll(html).toList()
            val hits = a.take(3).mapIndexed { i, m ->
                Hit(clean(m.groupValues[2]), clean(s.getOrNull(i)?.groupValues?.get(1) ?: ""), realUrl(m.groupValues[1]))
            }
            if (hits.isNotEmpty()) return hits
        }
        val w = get("https://en.wikipedia.org/w/api.php?action=query&list=search&srsearch=$enc&format=json&srlimit=3") ?: return if (html == null) null else emptyList()
        try {
            val arr = JSONObject(w).getJSONObject("query").getJSONArray("search")
            return (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                val t = o.getString("title")
                Hit(t, clean(o.optString("snippet")), "https://en.wikipedia.org/wiki/" + t.replace(' ', '_'))
            }
        } catch (e: Exception) { return emptyList() }
    }

    fun page(url: String): String? {
        val h = get(url) ?: return null
        return clean(h.replace(Regex("(?is)<(script|style|nav|footer|header)[^>]*>.*?</\\1>"), " ")).take(1500)
    }
}
