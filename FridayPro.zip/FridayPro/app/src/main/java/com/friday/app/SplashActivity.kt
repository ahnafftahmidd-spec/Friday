package com.friday.app
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.widget.FrameLayout
import android.widget.VideoView

/** Plays the dev-name splash video, then opens Friday. Tap to skip. */
class SplashActivity : Activity() {
    private var done = false
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val v = VideoView(this)
        setContentView(FrameLayout(this).apply {
            setBackgroundColor(0xFF000000.toInt())
            addView(v, FrameLayout.LayoutParams(-1, -1, Gravity.CENTER))
        })
        v.setVideoURI(Uri.parse("android.resource://$packageName/raw/friday_splash"))
        v.setOnCompletionListener { next() }
        v.setOnErrorListener { _, _, _ -> next(); true }
        v.setOnClickListener { next() }
        v.start()
    }
    private fun next() {
        if (done) return; done = true
        startActivity(Intent(this, MainActivity::class.java)); finish()
    }
}
