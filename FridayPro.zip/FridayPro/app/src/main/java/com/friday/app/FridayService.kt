package com.friday.app
import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Bitmap
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo as N
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/** Friday's hands and eyes. Must be switched on in Accessibility settings. */
class FridayService : AccessibilityService() {
    companion object { var i: FridayService? = null }
    override fun onServiceConnected() { i = this }
    override fun onDestroy() { i = null; super.onDestroy() }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    fun screen(): String {
        val sb = StringBuilder()
        var icons = 0
        fun walk(n: N?) {
            if (n == null || sb.length > 1200) return
            val t = n.text ?: n.contentDescription
            if (!t.isNullOrBlank()) sb.append(if (n.isClickable) "[btn] " else "").append(t).append('\n')
            else if (n.isEditable) sb.append("[input]\n")
            else if (n.isClickable && icons < 8) {
                icons++
                val r = Rect(); n.getBoundsInScreen(r)
                val id = n.viewIdResourceName?.substringAfterLast('/')?.replace('_', ' ') ?: "icon"
                sb.append("[icon: $id @${r.centerX()},${r.centerY()}]\n")
            }
            for (c in 0 until n.childCount) walk(n.getChild(c))
        }
        rootInActiveWindow?.let { walk(it) }
        if (sb.length < 40) { val b = screenshot(); if (b != null) sb.append(Vision.lines(b)) }
        return sb.toString().ifBlank { "(nothing readable)" }
    }

    fun screenshot(): Bitmap? {
        if (Build.VERSION.SDK_INT < 30) return null
        val latch = CountDownLatch(1)
        var bmp: Bitmap? = null
        takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : AccessibilityService.TakeScreenshotCallback {
            override fun onSuccess(r: AccessibilityService.ScreenshotResult) {
                bmp = Bitmap.wrapHardwareBuffer(r.hardwareBuffer, r.colorSpace)?.copy(Bitmap.Config.ARGB_8888, false)
                r.hardwareBuffer.close()
                latch.countDown()
            }
            override fun onFailure(code: Int) { latch.countDown() }
        })
        latch.await(4, TimeUnit.SECONDS)
        return bmp
    }

    private fun find(t: String): N? = rootInActiveWindow?.findAccessibilityNodeInfosByText(t)?.firstOrNull()

    fun tapXY(x: Int, y: Int): Boolean {
        val p = Path(); p.moveTo(x.toFloat(), y.toFloat())
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 60)).build()
        return dispatchGesture(g, null, null)
    }

    fun tap(t: String): Boolean {
        val xy = Regex("^\\s*(\\d+)\\s*,\\s*(\\d+)\\s*$").find(t)
        if (xy != null) return tapXY(xy.groupValues[1].toInt(), xy.groupValues[2].toInt())
        var n = find(t) ?: return false
        while (!n.isClickable) n = n.parent ?: return tapNode(n)
        return n.performAction(N.ACTION_CLICK)
    }
    private fun tapNode(n: N): Boolean { val r = Rect(); n.getBoundsInScreen(r); return tapXY(r.centerX(), r.centerY()) }

    fun type(t: String): Boolean {
        var n = rootInActiveWindow?.findFocus(N.FOCUS_INPUT)
        if (n == null) {
            fun firstEdit(x: N?): N? { if (x == null) return null; if (x.isEditable) return x; for (c in 0 until x.childCount) firstEdit(x.getChild(c))?.let { return it }; return null }
            n = firstEdit(rootInActiveWindow)
        }
        val node = n ?: return false
        return node.performAction(N.ACTION_SET_TEXT, Bundle().apply { putCharSequence(N.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, t) })
    }
    fun scroll(): Boolean {
        val r = rootInActiveWindow ?: return false
        fun f(n: N): N? { if (n.isScrollable) return n; for (c in 0 until n.childCount) n.getChild(c)?.let { f(it) }?.let { return it }; return null }
        return f(r)?.performAction(N.ACTION_SCROLL_FORWARD) ?: false
    }
    fun back() = performGlobalAction(GLOBAL_ACTION_BACK)
    fun home() = performGlobalAction(GLOBAL_ACTION_HOME)
}
