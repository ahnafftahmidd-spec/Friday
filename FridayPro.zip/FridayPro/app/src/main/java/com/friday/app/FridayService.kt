package com.friday.app
import android.accessibilityservice.AccessibilityService
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo as N

/** Friday's hands: reads the screen and taps/types/scrolls. User must enable it in Accessibility settings. */
class FridayService : AccessibilityService() {
    companion object { var i: FridayService? = null }
    override fun onServiceConnected() { i = this }
    override fun onDestroy() { i = null; super.onDestroy() }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    /** Compact screen description for the LLM (capped to keep prompts small and fast). */
    fun screen(): String {
        val out = StringBuilder(); val root = rootInActiveWindow ?: return "(empty)"
        fun walk(n: N?, d: Int) {
            if (n == null || out.length > 1500) return
            val t = n.text ?: n.contentDescription
            if (!t.isNullOrBlank()) out.append(if (n.isClickable) "[btn] " else "").append(t).append('\n')
            else if (n.isEditable) out.append("[input]\n")
            for (c in 0 until n.childCount) walk(n.getChild(c), d + 1)
        }
        walk(root, 0); return out.toString()
    }
    private fun find(t: String): N? = rootInActiveWindow?.findAccessibilityNodeInfosByText(t)?.firstOrNull()
    fun tap(t: String): Boolean {
        var n = find(t) ?: return false
        while (!n.isClickable) n = n.parent ?: return false
        return n.performAction(N.ACTION_CLICK)
    }
    fun type(t: String): Boolean {
        val n = rootInActiveWindow?.findFocus(N.FOCUS_INPUT) ?: return false
        return n.performAction(N.ACTION_SET_TEXT, Bundle().apply { putCharSequence(N.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, t) })
    }
    fun scroll(): Boolean = rootInActiveWindow?.let { r ->
        fun f(n: N): N? { if (n.isScrollable) return n; for (c in 0 until n.childCount) n.getChild(c)?.let { f(it) }?.let { return it }; return null }
        f(r)?.performAction(N.ACTION_SCROLL_FORWARD)
    } ?: false
    fun back() = performGlobalAction(GLOBAL_ACTION_BACK)
    fun home() = performGlobalAction(GLOBAL_ACTION_HOME)
}
