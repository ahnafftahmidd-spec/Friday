package com.friday.app
import android.app.Application
import android.app.ActivityManager
import android.content.Context
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import org.json.JSONObject
import java.util.concurrent.CopyOnWriteArrayList

/** Friday's shared brain: routes commands to fast direct tools, web, vision, memory or the local LLM. */
object Core {
    lateinit var app: Application
    lateinit var brain: Brain
    lateinit var mem: Mem
    lateinit var prefs: SharedPreferences
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    @Volatile var speaking = false
    @Volatile var working = false
    @Volatile var micBusy = false
    var pauseWake: (() -> Unit)? = null
    val listeners = CopyOnWriteArrayList<(String, Boolean) -> Unit>()
    class Pending(val run: () -> String)
    private var pending: Pending? = null
    private var visionCtx: String? = null
    private var visionTurns = 0

    private const val PLAIN = "You are Friday, a warm, concise assistant living on the user's phone. Answer in 1-3 short sentences, plain text only."
    private const val AGENT = "You are Friday, controlling an Android phone step by step. Reply with ONE JSON object only: {\"say\":\"short sentence\",\"action\":\"open_app|tap|type|scroll|back|home|done\",\"arg\":\"text\"}. tap arg is visible text or \"x,y\" for an icon. Use done when finished or if no phone action is needed."

    fun init(a: Application) {
        app = a; brain = Brain(a); mem = Mem(a); prefs = a.getSharedPreferences("friday", 0)
        tts = TextToSpeech(a) { s ->
            ttsReady = (s == TextToSpeech.SUCCESS)
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(id: String?) {}
                override fun onDone(id: String?) { speaking = false }
                override fun onError(id: String?) { speaking = false }
            })
        }
    }

    fun defaultKey(): String {
        val mi = ActivityManager.MemoryInfo()
        (app.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
        return if (mi.totalMem >= 5_000_000_000L) "standard" else "light"
    }
    fun model(): Model = modelByKey(prefs.getString("model", null) ?: defaultKey())

    fun speak(t: String) {
        if (!ttsReady || !prefs.getBoolean("speak", true)) return
        speaking = true
        tts?.speak(t.take(400), TextToSpeech.QUEUE_FLUSH, null, "f" + System.nanoTime())
    }

    private fun emit(t: String, user: Boolean) {
        if (t.isBlank()) return
        mem.log(user, t)
        listeners.forEach { it(t, user) }
    }

    /** Blocking: call from a background thread. */
    fun handle(input: String): String {
        val text = input.trim()
        if (text.isEmpty()) return ""
        working = true
        emit(text, true)
        val reply = try { route(text) } catch (e: Exception) { "Sorry, that failed: ${e.message}" } finally { working = false }
        emit(reply, false)
        speak(reply)
        return reply
    }

    fun describe(bmp: Bitmap): String {
        working = true
        emit("📷 Image shared", true)
        val reply = try {
            val a = Vision.analyze(bmp)
            visionCtx = a; visionTurns = 3
            brain.chat(PLAIN, "Image analysis: $a\nDescribe what the image shows in 2-3 sentences and mention any text.").trim()
        } catch (e: Exception) { "I couldn't analyse that image: ${e.message}" } finally { working = false }
        emit(reply, false); speak(reply)
        return reply
    }

    private fun memCtx(): String {
        val n = mem.notes().takeLast(8).joinToString("; ").take(450)
        return if (n.isEmpty()) "" else " Facts the user asked you to remember: $n."
    }

    private fun needControl() = "Phone control is off. Turn it on in the Settings tab."

    private fun route(t: String): String {
        val s = t.trim().trimEnd('.', '!', '?')
        val l = s.lowercase()
        pending?.let { p ->
            pending = null
            if (Regex("^(yes|yeah|yep|yup|confirm|send it|do it|go ahead|ok|okay|sure)\\b").containsMatchIn(l)) return p.run()
            if (Regex("^(no|nope|cancel|stop|don't|dont|never mind)\\b").containsMatchIn(l)) return "Okay, cancelled."
        }
        fun m(p: String) = Regex(p, RegexOption.IGNORE_CASE).find(s)

        m("^(?:please )?remember (?:that )?(.+)")?.let { mem.add(it.groupValues[1]); return "Got it. I'll remember that." }
        if (Regex("^(forget everything|clear (my )?(memory|notes))").containsMatchIn(l)) { mem.clearNotes(); return "Memory cleared." }
        m("^forget (?:that |about )?(.+)")?.let {
            return if (mem.forget(it.groupValues[1]) > 0) "Forgotten." else "I didn't have anything about that."
        }
        if (Regex("what do you (remember|know about me)|show (my )?(notes|memory)").containsMatchIn(l)) {
            val n = mem.notes()
            return if (n.isEmpty()) "I don't have any notes yet. Say “remember that …” to teach me." else "Here's what I remember:\n" + n.joinToString("\n") { "• $it" }
        }
        if (Regex("what can you do|^help$").containsMatchIn(l))
            return "I can call and text your contacts, set alarms and timers, search the web, read images and your screen, open apps, tap and type for you, and remember things. Say “Hey Friday” if wake word is on."

        m("^call (.+)")?.let { return callCmd(it.groupValues[1].trim()) }
        m("^(?:send (?:a )?(?:text|message|sms) to|text|message|sms)\\s+(.+?)\\s+(?:saying|that says|to say|say|:)\\s*(.+)$")?.let {
            return smsCmd(it.groupValues[1].trim(), it.groupValues[2].trim())
        }
        if (l.contains("timer")) {
            Regex("(\\d+)\\s*(second|sec|minute|min|hour|hr)").find(l)?.let {
                val n = it.groupValues[1].toInt(); val u = it.groupValues[2]
                Tools.timer(if (u.startsWith("h")) n * 3600 else if (u.startsWith("m")) n * 60 else n)
                return "Timer set for $n $u."
            }
            return "For how long? Try “set a timer for 10 minutes”."
        }
        if (Regex("\\balarm\\b|wake me").containsMatchIn(l)) {
            val c = Tools.parseClock(l) ?: return "What time? Try “set an alarm for 7:30 am”."
            Tools.alarm(c.first, c.second)
            return "Alarm set for %d:%02d.".format(c.first, c.second)
        }
        m("^(?:search(?: the web)?(?: for)?|google|look up|look for|find out|news (?:about|on))\\s+(.+)")?.let { return web(it.groupValues[1]) }
        if (Regex("\\b(weather|latest news|news today)\\b").containsMatchIn(l)) return web(s)
        Regex("https?://\\S+").find(s)?.let { return readUrl(it.value) }
        if (Regex("what'?s on (my )?screen|(read|describe) (my |the )?screen").containsMatchIn(l)) return readScreen()
        m("^(?:open|launch|start)\\s+(.+)")?.let {
            val a = it.groupValues[1].trim()
            return if (Tools.openApp(a)) "Opening $a." else "I couldn't find an app called $a."
        }
        val svc = FridayService.i
        if (Regex("^(go )?(to )?(the )?home( screen)?$").containsMatchIn(l)) return if (svc?.home() == true) "Done." else needControl()
        if (Regex("^(go )?back$").containsMatchIn(l)) return if (svc?.back() == true) "Done." else needControl()
        if (Regex("^scroll( down)?$").containsMatchIn(l)) return if (svc?.scroll() == true) "Done." else needControl()
        if (Regex("\\b(tap|click|press|scroll|swipe|type|turn (on|off)|enable|disable|toggle|install|navigate|select)\\b").containsMatchIn(l)) return agent(s)
        return chat(s)
    }

    private fun callCmd(name: String): String {
        val c = Tools.contact(name) ?: return if (!Tools.has("android.permission.READ_CONTACTS"))
            "I need contacts permission. Open the Settings tab and tap Grant permissions." else "I couldn't find $name in your contacts."
        pending = Pending { Tools.call(c.second); "Calling ${c.first}…" }
        return "Call ${c.first}? Say yes to confirm."
    }

    private fun smsCmd(name: String, msg: String): String {
        val c = Tools.contact(name) ?: return if (!Tools.has("android.permission.READ_CONTACTS"))
            "I need contacts permission. Open the Settings tab and tap Grant permissions." else "I couldn't find $name in your contacts."
        pending = Pending {
            if (!Tools.has("android.permission.SEND_SMS")) "I need the SMS permission first."
            else if (Tools.sms(c.second, msg)) "Sent to ${c.first}." else "Sending failed."
        }
        return "Send to ${c.first}: “$msg”? Say yes to confirm."
    }

    private fun web(q: String): String {
        val res = Net.search(q) ?: return "I couldn't reach the web. Check your connection."
        if (res.isEmpty()) return "I found no results for that."
        val ctx = res.joinToString("\n") { "- ${it.title}: ${it.snippet}" }.take(1300)
        val a = brain.chat(PLAIN, "Web results:\n$ctx\n\nQuestion: $q\nAnswer briefly using only these results.").trim()
        return a + "\n\nSource: " + res[0].url
    }

    private fun readUrl(url: String): String {
        val txt = Net.page(url) ?: return "I couldn't open that page."
        return brain.chat(PLAIN, "Page text:\n$txt\n\nSummarize this page in 3 short sentences.").trim()
    }

    private fun readScreen(): String {
        val svc = FridayService.i ?: return needControl()
        return brain.chat(PLAIN, "Screen contents:\n${svc.screen()}\n\nIn 2-3 sentences, say what is on this phone screen.").trim()
    }

    private fun chat(s: String): String {
        var sys = PLAIN + memCtx()
        if (visionCtx != null && visionTurns > 0) { sys += " The user recently shared an image. Analysis: $visionCtx"; visionTurns-- }
        return brain.reply(sys, mem.recent(5).map { it.first to it.second.take(240) })
    }

    private fun agent(goal: String): String {
        var hist = ""
        var last = ""
        for (step in 0 until 6) {
            val svc = FridayService.i
            val screen = if (step > 0) (svc?.screen() ?: "(phone control is off)") else "(not shown yet)"
            val raw = brain.chat(AGENT + memCtx(), "Goal: $goal\nDone so far:$hist\nScreen:\n$screen")
            val j = try { JSONObject(raw.substring(raw.indexOf('{'), raw.lastIndexOf('}') + 1)) } catch (e: Exception) { return raw.take(300) }
            val say = j.optString("say")
            if (say.isNotBlank()) last = say
            val action = j.optString("action")
            val arg = j.optString("arg")
            val ok = when (action) {
                "open_app" -> Tools.openApp(arg)
                "tap" -> svc?.tap(arg) ?: false
                "type" -> svc?.type(arg) ?: false
                "scroll" -> svc?.scroll() ?: false
                "back" -> svc?.back() ?: false
                "home" -> svc?.home() ?: false
                else -> return last.ifBlank { "Done." }
            }
            hist += "\n$action($arg)=${if (ok) "ok" else "failed"}"
            Thread.sleep(1500)
        }
        return last.ifBlank { "I stopped after 6 steps." }
    }
}
