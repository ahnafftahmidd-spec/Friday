package com.friday.app
import android.content.Context
import android.content.Intent
import org.json.JSONObject

/** Observe -> think (local Qwen) -> act loop. Capped at MAX steps so it can't run away. */
class Agent(private val ctx: Context, private val brain: Brain, private val say: (String) -> Unit) {
    private val MAX = 8
    private val SYS = """You are Friday, a concise on-device phone assistant. You control the phone step by step.
Reply with ONE JSON object only: {"say":"short sentence to user","action":"open_app|tap|type|scroll|back|home|done","arg":"text"}
open_app arg = app name. tap arg = visible text. type arg = text to enter. Use done when finished."""

    fun run(goal: String) {
        var hist = ""
        repeat(MAX) {
            val svc = FridayService.i
            val screen = svc?.screen() ?: "(accessibility service not enabled)"
            val raw = brain.chat(SYS, "Goal: $goal\nSteps so far:$hist\nScreen:\n$screen")
            val j = try { JSONObject(raw.substring(raw.indexOf('{'), raw.lastIndexOf('}') + 1)) } catch (e: Exception) { say(raw.take(200)); return }
            val action = j.optString("action"); val arg = j.optString("arg")
            j.optString("say").takeIf { it.isNotBlank() }?.let(say)
            val ok = when (action) {
                "open_app" -> openApp(arg)
                "tap" -> svc?.tap(arg) ?: false
                "type" -> svc?.type(arg) ?: false
                "scroll" -> svc?.scroll() ?: false
                "back" -> svc?.back() ?: false
                "home" -> svc?.home() ?: false
                "done" -> return
                else -> false
            }
            hist += "\n$action($arg)=${if (ok) "ok" else "failed"}"
            Thread.sleep(1500)
        }
        say("I stopped after $MAX steps.")
    }
    private fun openApp(name: String): Boolean {
        val pm = ctx.packageManager
        val app = pm.getInstalledApplications(0).firstOrNull { pm.getApplicationLabel(it).toString().contains(name, true) } ?: return false
        val i = pm.getLaunchIntentForPackage(app.packageName) ?: return false
        ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); return true
    }
}
