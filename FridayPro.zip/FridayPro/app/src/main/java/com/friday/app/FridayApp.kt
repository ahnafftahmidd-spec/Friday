package com.friday.app
import android.app.Application
class FridayApp : Application() { override fun onCreate() { super.onCreate(); Core.init(this) } }
