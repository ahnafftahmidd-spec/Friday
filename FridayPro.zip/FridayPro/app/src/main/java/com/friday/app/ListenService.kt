package com.friday.app
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.SpeechRecognizer

/** "Hey Friday" listener. Runs in the background with a notification. */
class ListenService : Service() {
    private val h = Handler(Looper.getMainLooper())
    private var sr: SpeechRecognizer? = null
    private var listening = false
    private var startedAt = 0L
    private var awaiting = false

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("friday", "Friday listening", NotificationManager.IMPORTANCE_LOW))
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "friday").setContentTitle("Friday is listening")
            .setContentText("Say “Hey Friday” and a command").setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(pi).setOngoing(true).build()
        if (android.os.Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE) else startForeground(1, n)
        if (sr == null) {
            val r = SpeechRecognizer.createSpeechRecognizer(this)
            r.setRecognitionListener(object : RecognitionListener {
                override fun onResults(b: Bundle) { listening = false; b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { process(it) } }
                override fun onError(e: Int) { listening = false }
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(p: Bundle?) {}
                override fun onEvent(t: Int, p: Bundle?) {}
            })
            sr = r
            Core.pauseWake = { sr?.cancel(); listening = false }
            h.post(tick)
        }
        return START_STICKY
    }

    private val tick = object : Runnable {
        override fun run() {
            val now = System.currentTimeMillis()
            if (listening && now - startedAt > 20000) { sr?.cancel(); listening = false }
            if (!listening && !Core.micBusy && !Core.speaking && !Core.working) {
                listening = true; startedAt = now
                try { sr?.startListening(recognizerIntent()) } catch (e: Exception) { listening = false }
            }
            h.postDelayed(this, 1500)
        }
    }

    private fun process(text: String) {
        val i = text.lowercase().indexOf("friday")
        val cmd: String
        if (awaiting) { cmd = text; awaiting = false }
        else if (i >= 0) {
            cmd = text.substring(i + 6).trim(' ', ',', '.', '!')
            if (cmd.isEmpty()) { awaiting = true; h.postDelayed({ awaiting = false }, 10000); Core.speak("Yes?"); return }
        } else return
        Thread { Core.handle(cmd) }.start()
    }

    override fun onDestroy() {
        h.removeCallbacks(tick); sr?.destroy(); sr = null; Core.pauseWake = null
        super.onDestroy()
    }
}
