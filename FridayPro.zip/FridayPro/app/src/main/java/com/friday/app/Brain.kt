package com.friday.app
import android.content.Context
import com.google.ai.edge.litertlm.Backend
import com.google.ai.edge.litertlm.Contents
import com.google.ai.edge.litertlm.ConversationConfig
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import com.google.ai.edge.litertlm.Message
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import java.io.File

/** Runs the chosen Qwen: .task files via MediaPipe, .litertlm files (Qwen3 4B) via LiteRT-LM. */
class Brain(private val ctx: Context) {
    private val dir = ctx.getExternalFilesDir(null)
    fun fileFor(m: Model) = File(dir, m.file)

    /** The file of the selected model (falls back to the older qwen.task if present). */
    fun active(): File {
        val f = fileFor(Core.model())
        if (f.exists()) return f
        val legacy = File(dir, "qwen.task")
        return if (!f.name.endsWith(".litertlm") && legacy.exists()) legacy else f
    }
    val available: Boolean get() = active().let { it.exists() && it.length() > 50_000_000L }

    private var mp: LlmInference? = null
    private var mpPath = ""
    private var lm: Engine? = null
    private var lmPath = ""

    fun warm() { try { reply("You are a helper.", listOf(true to "hi")) } catch (e: Exception) { } }

    @Synchronized fun reply(system: String, turns: List<Pair<Boolean, String>>): String {
        if (!available) return "My AI model isn't ready yet."
        val f = active()
        val t = alternate(turns)
        if (t.isEmpty()) return ""
        return if (f.name.endsWith(".litertlm")) viaLm(f, system, t) else viaMp(f, system, t)
    }

    fun chat(system: String, user: String): String = reply(system, listOf(true to user))

    private fun alternate(turns: List<Pair<Boolean, String>>): List<Pair<Boolean, String>> {
        val out = ArrayList<Pair<Boolean, String>>()
        for (t in turns) { if (out.isNotEmpty() && out.last().first == t.first) out[out.size - 1] = t else out.add(t) }
        while (out.isNotEmpty() && !out.first().first) out.removeAt(0)
        return out
    }

    private fun viaMp(f: File, system: String, turns: List<Pair<Boolean, String>>): String {
        if (lm != null) { try { lm?.close() } catch (e: Exception) { }; lm = null; lmPath = "" }
        if (mp == null || mpPath != f.path) {
            try { mp?.close() } catch (e: Exception) { }
            mp = LlmInference.createFromOptions(ctx,
                LlmInference.LlmInferenceOptions.builder().setModelPath(f.absolutePath).setMaxTokens(1280).build())
            mpPath = f.path
        }
        val sb = StringBuilder("<|im_start|>system\n$system<|im_end|>\n")
        for ((user, txt) in turns) sb.append("<|im_start|>${if (user) "user" else "assistant"}\n$txt<|im_end|>\n")
        sb.append("<|im_start|>assistant\n")
        return (mp?.generateResponse(sb.toString()) ?: "").trim()
    }

    private fun viaLm(f: File, system: String, turns: List<Pair<Boolean, String>>): String {
        if (mp != null) { try { mp?.close() } catch (e: Exception) { }; mp = null; mpPath = "" }
        if (lm == null || lmPath != f.path) {
            try { lm?.close() } catch (e: Exception) { }
            val e = Engine(EngineConfig(modelPath = f.path, backend = Backend.CPU(), cacheDir = ctx.cacheDir.path))
            e.initialize()
            lm = e
            lmPath = f.path
        }
        val engine = lm ?: return ""
        val init = turns.dropLast(1).map { if (it.first) Message.user(it.second) else Message.model(it.second) }
        val cfg = ConversationConfig(systemInstruction = Contents.of(system), initialMessages = init)
        engine.createConversation(cfg).use { c ->
            val raw = c.sendMessage(turns.last().second + " /no_think").toString()
            return Regex("(?s)<think>.*?</think>").replace(raw, "").replace("<think>", "").trim()
        }
    }
}
