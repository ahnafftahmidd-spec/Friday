package com.friday.app
import android.content.Context
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import java.io.File

class Brain(private val ctx: Context) {
    val file = File(ctx.getExternalFilesDir(null), "qwen.task")
    val available: Boolean get() = file.exists() && file.length() > 50_000_000L
    private var llm: LlmInference? = null

    @Synchronized private fun engine(): LlmInference? {
        if (llm == null && available) {
            llm = LlmInference.createFromOptions(ctx,
                LlmInference.LlmInferenceOptions.builder()
                    .setModelPath(file.absolutePath).setMaxTokens(1024).build())
        }
        return llm
    }
    fun warm() { engine() }
    fun chat(system: String, user: String): String {
        val e = engine() ?: return "My AI model isn't ready yet."
        return e.generateResponse("<|im_start|>system\n$system<|im_end|>\n<|im_start|>user\n$user<|im_end|>\n<|im_start|>assistant\n")
    }
}
