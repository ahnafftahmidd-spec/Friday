package com.friday.app
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.AlarmClock
import android.provider.ContactsContract.CommonDataKinds.Phone
import android.telephony.SmsManager
import java.util.Calendar

/** Direct phone actions: far more reliable than tapping through screens. */
object Tools {
    private fun ctx(): Context = FridayService.i ?: Core.app
    fun has(p: String): Boolean = Core.app.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED
    fun launch(i: Intent) { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); ctx().startActivity(i) }

    fun contact(q: String): Pair<String, String>? {
        if (Regex("^[+\\d][\\d\\s\\-()]{4,}$").matches(q)) return q to q
        if (!has("android.permission.READ_CONTACTS")) return null
        Core.app.contentResolver.query(Phone.CONTENT_URI, arrayOf(Phone.DISPLAY_NAME, Phone.NUMBER),
            "${Phone.DISPLAY_NAME} LIKE ?", arrayOf("%$q%"), null)?.use { c ->
            if (c.moveToFirst()) return c.getString(0) to c.getString(1)
        }
        return null
    }

    fun call(num: String) {
        val uri = Uri.parse("tel:" + Uri.encode(num))
        launch(Intent(if (has("android.permission.CALL_PHONE")) Intent.ACTION_CALL else Intent.ACTION_DIAL, uri))
    }

    @Suppress("DEPRECATION")
    fun sms(num: String, msg: String): Boolean {
        return try {
            val sm = if (android.os.Build.VERSION.SDK_INT >= 31) Core.app.getSystemService(SmsManager::class.java) else SmsManager.getDefault()
            sm.sendMultipartTextMessage(num, null, sm.divideMessage(msg), null, null)
            true
        } catch (e: Exception) { false }
    }

    fun alarm(h: Int, m: Int) {
        launch(Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, h).putExtra(AlarmClock.EXTRA_MINUTES, m)
            .putExtra(AlarmClock.EXTRA_MESSAGE, "Friday").putExtra(AlarmClock.EXTRA_SKIP_UI, true))
    }
    fun timer(sec: Int) {
        launch(Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, sec)
            .putExtra(AlarmClock.EXTRA_MESSAGE, "Friday").putExtra(AlarmClock.EXTRA_SKIP_UI, true))
    }

    fun parseClock(s: String): Pair<Int, Int>? {
        Regex("in (\\d+)\\s*(minute|min|hour|hr)").find(s)?.let {
            val n = it.groupValues[1].toInt()
            val c = Calendar.getInstance()
            c.add(Calendar.MINUTE, if (it.groupValues[2].startsWith("h")) n * 60 else n)
            return c.get(Calendar.HOUR_OF_DAY) to c.get(Calendar.MINUTE)
        }
        val m = Regex("(\\d{1,2})(?::(\\d{2}))?\\s*(a\\.?m\\.?|p\\.?m\\.?)?").find(s) ?: return null
        var h = m.groupValues[1].toInt()
        val min = if (m.groupValues[2].isEmpty()) 0 else m.groupValues[2].toInt()
        val ap = m.groupValues[3]
        if (ap.startsWith("p") && h < 12) h += 12
        if (ap.startsWith("a") && h == 12) h = 0
        return if (h in 0..23 && min in 0..59) h to min else null
    }

    fun openApp(name: String): Boolean {
        val pm = Core.app.packageManager
        val app = pm.getInstalledApplications(0).firstOrNull { pm.getApplicationLabel(it).toString().contains(name, true) } ?: return false
        val i = pm.getLaunchIntentForPackage(app.packageName) ?: return false
        launch(i)
        return true
    }
}
