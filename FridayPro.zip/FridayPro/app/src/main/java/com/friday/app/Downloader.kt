package com.friday.app
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

data class Model(val name: String, val url: String, val mb: Int)

val LIGHT = Model("Qwen2.5 0.5B",
    "https://huggingface.co/litert-community/Qwen2.5-0.5B-Instruct/resolve/main/Qwen2.5-0.5B-Instruct_multi-prefill-seq_q8_ekv1280.task", 547)
val STANDARD = Model("Qwen2.5 1.5B",
    "https://huggingface.co/litert-community/Qwen2.5-1.5B-Instruct/resolve/main/Qwen2.5-1.5B-Instruct_multi-prefill-seq_q8_ekv1280.task", 1550)

/** Resumable download: if interrupted, the next try continues where it stopped. */
class Downloader(private val dest: File) {
    fun run(url: String, onProgress: (Long, Long) -> Unit): Result<Unit> {
        try {
            val part = File(dest.path + ".part")
            var have = if (part.exists()) part.length() else 0L
            val c = URL(url).openConnection() as HttpURLConnection
            c.instanceFollowRedirects = true
            c.connectTimeout = 20000
            c.readTimeout = 30000
            if (have > 0) c.setRequestProperty("Range", "bytes=$have-")
            c.connect()
            val code = c.responseCode
            if (code == 416) {
                part.renameTo(dest)
                return Result.success(Unit)
            }
            if (code != 200 && code != 206) throw IOException("Server replied $code")
            val resumed = code == 206
            if (!resumed) have = 0L
            val total = have + c.contentLengthLong
            var done = have
            var last = 0L
            FileOutputStream(part, resumed).use { out ->
                c.inputStream.use { inp ->
                    val buf = ByteArray(256 * 1024)
                    while (true) {
                        val n = inp.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        done += n
                        val now = System.currentTimeMillis()
                        if (now - last > 300) { onProgress(done, total); last = now }
                    }
                }
            }
            onProgress(total, total)
            if (dest.exists()) dest.delete()
            if (!part.renameTo(dest)) throw IOException("Could not save the file")
            return Result.success(Unit)
        } catch (e: Exception) {
            return Result.failure(e)
        }
    }
}
