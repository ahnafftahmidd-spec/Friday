package com.friday.app
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

data class Model(val key: String, val name: String, val mb: Int, val file: String, val url: String = "", val repo: String = "")

val LIGHT = Model("light", "Qwen2.5 0.5B", 547, "qwen-light.task",
    "https://huggingface.co/litert-community/Qwen2.5-0.5B-Instruct/resolve/main/Qwen2.5-0.5B-Instruct_multi-prefill-seq_q8_ekv1280.task")
val STANDARD = Model("standard", "Qwen2.5 1.5B", 1550, "qwen-standard.task",
    "https://huggingface.co/litert-community/Qwen2.5-1.5B-Instruct/resolve/main/Qwen2.5-1.5B-Instruct_multi-prefill-seq_q8_ekv1280.task")
/** File name is looked up online at download time. */
val LARGE = Model("large", "Qwen3 4B", 2400, "qwen-large.litertlm", repo = "litert-community/Qwen3-4B")
val MODELS = listOf(LIGHT, STANDARD, LARGE)
fun modelByKey(k: String): Model = MODELS.firstOrNull { it.key == k } ?: STANDARD

object Hf {
    /** Finds the smallest .litertlm file in a Hugging Face repo and returns its download URL. */
    fun resolve(repo: String): String? {
        try {
            val c = URL("https://huggingface.co/api/models/$repo?blobs=true").openConnection() as HttpURLConnection
            c.connectTimeout = 15000; c.readTimeout = 20000
            if (c.responseCode != 200) return null
            val s = JSONObject(c.inputStream.bufferedReader().use { it.readText() }).getJSONArray("siblings")
            var best: String? = null
            var bestSize = Long.MAX_VALUE
            for (i in 0 until s.length()) {
                val o = s.getJSONObject(i)
                val n = o.getString("rfilename")
                val size = o.optLong("size", 0L)
                if (n.endsWith(".litertlm") && size >= 100_000_000L && size < bestSize) { best = n; bestSize = size }
            }
            return best?.let { "https://huggingface.co/$repo/resolve/main/$it" }
        } catch (e: Exception) { return null }
    }
}

/** Resumable download: if interrupted, the next try continues where it stopped. */
class Downloader(private val dest: File) {
    fun run(url: String, onProgress: (Long, Long) -> Unit): Result<Unit> {
        try {
            val part = File(dest.path + ".part")
            var have = if (part.exists()) part.length() else 0L
            val c = URL(url).openConnection() as HttpURLConnection
            c.instanceFollowRedirects = true
            c.connectTimeout = 20000
            c.readTimeout = 30000
            if (have > 0) c.setRequestProperty("Range", "bytes=$have-")
            c.connect()
            val code = c.responseCode
            if (code == 416) {
                part.renameTo(dest)
                return Result.success(Unit)
            }
            if (code != 200 && code != 206) throw IOException("Server replied $code")
            val resumed = code == 206
            if (!resumed) have = 0L
            val total = have + c.contentLengthLong
            var done = have
            var last = 0L
            FileOutputStream(part, resumed).use { out ->
                c.inputStream.use { inp ->
                    val buf = ByteArray(256 * 1024)
                    while (true) {
                        val n = inp.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        done += n
                        val now = System.currentTimeMillis()
                        if (now - last > 300) { onProgress(done, total); last = now }
                    }
                }
            }
            onProgress(total, total)
            if (dest.exists()) dest.delete()
            if (!part.renameTo(dest)) throw IOException("Could not save the file")
            return Result.success(Unit)
        } catch (e: Exception) {
            return Result.failure(e)
        }
    }
}
