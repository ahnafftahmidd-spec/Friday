package com.friday.app
import android.Manifest
import android.app.Activity
import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.widget.*

class MainActivity : Activity() {
    private class Step(val badge: TextView, val sub: TextView, val bar: ProgressBar, val btn: TextView)

    private lateinit var brain: Brain
    private lateinit var agent: Agent
    private lateinit var voice: Voice
    private lateinit var root: FrameLayout
    private var onChat = false
    private var busy = false
    private var downloading = false

    private var sModel: Step? = null
    private var sMic: Step? = null
    private var sAcc: Step? = null
    private var startBtn: TextView? = null

    private var list: LinearLayout? = null
    private var scroll: ScrollView? = null
    private var empty: View? = null
    private var input: EditText? = null
    private var statusText: TextView? = null
    private var statusDot: View? = null

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = C.bg
        window.navigationBarColor = C.bg
        root = FrameLayout(this)
        root.setBackgroundColor(C.bg)
        root.fitsSystemWindows = true
        setContentView(root)
        brain = Brain(this)
        voice = Voice(this) { heard -> runOnUiThread { send(heard) } }
        agent = Agent(this, brain) { t -> runOnUiThread { addMsg(t, false) }; voice.speak(t) }
        if (brain.available) { showChat(); Thread { brain.warm() }.start() } else showSetup()
    }

    override fun onResume() {
        super.onResume()
        if (!onChat) refreshSetup()
    }

    override fun onDestroy() { voice.stop(); super.onDestroy() }

    // ---------------- Setup ----------------

    private fun pickModel(): Model {
        val mi = ActivityManager.MemoryInfo()
        (getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
        return if (mi.totalMem >= 5_000_000_000L) STANDARD else LIGHT
    }

    private fun addStep(parent: LinearLayout, n: String, title: String, sub: String, withBar: Boolean, action: String): Step {
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.background = shape(C.card, 18, C.line)
        card.setPadding(dp(16), dp(16), dp(16), dp(16))
        val top = LinearLayout(this)
        top.gravity = Gravity.CENTER_VERTICAL
        val badge = label(n, 14f, C.text, true)
        badge.gravity = Gravity.CENTER
        badge.background = shape(C.line, 14)
        top.addView(badge, LinearLayout.LayoutParams(dp(28), dp(28)))
        val tcol = LinearLayout(this)
        tcol.orientation = LinearLayout.VERTICAL
        tcol.setPadding(dp(14), 0, 0, 0)
        tcol.addView(label(title, 16f, C.text, true))
        val s = label(sub, 13f, C.dim)
        tcol.addView(s)
        top.addView(tcol, LinearLayout.LayoutParams(0, -2, 1f))
        card.addView(top)
        val bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
        bar.max = 1000
        bar.progressTintList = ColorStateList.valueOf(C.accent)
        bar.progressBackgroundTintList = ColorStateList.valueOf(C.line)
        bar.visibility = if (withBar) View.VISIBLE else View.GONE
        val bp = LinearLayout.LayoutParams(-1, dp(6))
        bp.topMargin = dp(14)
        card.addView(bar, bp)
        val btn = pill(action, false)
        btn.visibility = View.GONE
        val kp = LinearLayout.LayoutParams(-2, -2)
        kp.topMargin = dp(12)
        card.addView(btn, kp)
        val cp = LinearLayout.LayoutParams(-1, -2)
        cp.bottomMargin = dp(12)
        parent.addView(card, cp)
        return Step(badge, s, bar, btn)
    }

    private fun showSetup() {
        onChat = false
        val page = LinearLayout(this)
        page.orientation = LinearLayout.VERTICAL
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(22), dp(30), dp(22), dp(12))
        val logo = ImageView(this)
        logo.setImageResource(R.mipmap.ic_launcher)
        col.addView(logo, LinearLayout.LayoutParams(dp(60), dp(60)))
        val h = label("Welcome to Friday", 28f, C.text, true)
        h.setPadding(0, dp(18), 0, 0)
        col.addView(h)
        val sub = label("Your private AI assistant. It runs on this phone, so your conversations stay with you.", 15f, C.dim)
        sub.setPadding(0, dp(6), 0, dp(24))
        col.addView(sub)

        val m = addStep(col, "1", "AI model", "Preparing…", true, "Retry")
        val mic = addStep(col, "2", "Voice", "Lets you talk to Friday and hear replies.", false, "Allow microphone")
        val acc = addStep(col, "3", "Phone control", "Lets Friday open apps, tap and type for you. In Settings, find Friday under Installed or Downloaded apps and switch it on.", false, "Open settings")
        sModel = m; sMic = mic; sAcc = acc
        m.btn.setOnClickListener { startDownload() }
        mic.btn.setOnClickListener { requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1) }
        acc.btn.setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }

        val start = pill("Start using Friday", true)
        start.alpha = 0.4f
        start.isEnabled = false
        start.setOnClickListener { showChat(); Thread { brain.warm() }.start() }
        startBtn = start

        val sv = ScrollView(this)
        sv.isVerticalScrollBarEnabled = false
        sv.addView(col)
        page.addView(sv, LinearLayout.LayoutParams(-1, 0, 1f))
        val sp = LinearLayout.LayoutParams(-1, -2)
        sp.setMargins(dp(22), dp(8), dp(22), dp(18))
        page.addView(start, sp)
        root.removeAllViews()
        root.addView(page, FrameLayout.LayoutParams(-1, -1))

        refreshSetup()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
        }
        if (brain.available) markModelDone() else startDownload()
    }

    private fun mark(s: Step, done: Boolean, doneText: String) {
        if (done) {
            s.badge.text = "✓"
            s.badge.background = shape(C.ok, 14)
            s.badge.setTextColor(0xFF08210F.toInt())
            s.sub.text = doneText
            s.btn.visibility = View.GONE
        } else {
            s.btn.visibility = View.VISIBLE
        }
    }

    private fun refreshSetup() {
        val micOk = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        sMic?.let { mark(it, micOk, "Microphone ready.") }
        sAcc?.let { mark(it, FridayService.i != null, "Phone control is on.") }
    }

    private fun markModelDone() {
        val m = sModel ?: return
        m.bar.visibility = View.GONE
        mark(m, true, "Ready. Runs offline on your phone.")
        startBtn?.let { it.alpha = 1f; it.isEnabled = true }
    }

    private fun startDownload() {
        val m = sModel ?: return
        if (downloading) return
        downloading = true
        val model = pickModel()
        m.sub.text = "Downloading ${model.name} (about ${model.mb} MB). Keep this screen open, Wi-Fi recommended."
        m.btn.visibility = View.GONE
        m.bar.visibility = View.VISIBLE
        m.bar.progress = 0
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        Thread {
            val r = Downloader(brain.file).run(model.url) { done, total ->
                runOnUiThread {
                    if (total > 0) m.bar.progress = (done * 1000 / total).toInt()
                    m.sub.text = "Downloading ${model.name} · ${done / 1_000_000} of ${total / 1_000_000} MB"
                }
            }
            runOnUiThread {
                downloading = false
                window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                if (r.isSuccess) {
                    markModelDone()
                } else {
                    m.bar.visibility = View.GONE
                    m.sub.text = "Download stopped: ${r.exceptionOrNull()?.message}. Check your connection and tap Retry. It will resume."
                    m.btn.visibility = View.VISIBLE
                }
            }
        }.start()
    }

    // ---------------- Chat ----------------

    private fun showChat() {
        onChat = true
        val page = LinearLayout(this)
        page.orientation = LinearLayout.VERTICAL

        val head = LinearLayout(this)
        head.gravity = Gravity.CENTER_VERTICAL
        head.setPadding(dp(18), dp(14), dp(18), dp(14))
        val logo = ImageView(this)
        logo.setImageResource(R.mipmap.ic_launcher)
        head.addView(logo, LinearLayout.LayoutParams(dp(38), dp(38)))
        val hc = LinearLayout(this)
        hc.orientation = LinearLayout.VERTICAL
        hc.setPadding(dp(12), 0, 0, 0)
        hc.addView(label("Friday", 18f, C.text, true))
        val srow = LinearLayout(this)
        srow.gravity = Gravity.CENTER_VERTICAL
        val dot = View(this)
        dot.background = shape(C.ok, 4)
        srow.addView(dot, LinearLayout.LayoutParams(dp(8), dp(8)))
        val st = label("Ready", 12f, C.dim)
        st.setPadding(dp(6), 0, 0, 0)
        srow.addView(st)
        hc.addView(srow)
        head.addView(hc, LinearLayout.LayoutParams(0, -2, 1f))
        page.addView(head)
        val div = View(this)
        div.setBackgroundColor(C.line)
        page.addView(div, LinearLayout.LayoutParams(-1, dp(1)))

        val msgs = LinearLayout(this)
        msgs.orientation = LinearLayout.VERTICAL
        msgs.setPadding(dp(14), dp(14), dp(14), dp(14))
        val sc = ScrollView(this)
        sc.isVerticalScrollBarEnabled = false
        sc.addView(msgs)
        page.addView(sc, LinearLayout.LayoutParams(-1, 0, 1f))

        val emp = LinearLayout(this)
        emp.orientation = LinearLayout.VERTICAL
        emp.gravity = Gravity.CENTER_HORIZONTAL
        emp.setPadding(0, dp(48), 0, 0)
        emp.addView(label("How can I help?", 24f, C.text, true))
        val es = label("Ask me anything, or tell me to do something on your phone.", 14f, C.dim)
        es.gravity = Gravity.CENTER
        es.setPadding(dp(20), dp(8), dp(20), dp(20))
        emp.addView(es)
        for (s in listOf("Open Settings", "Go to the home screen", "What can you do?")) {
            val chip = pill(s, false)
            chip.setOnClickListener { send(s) }
            val cp = LinearLayout.LayoutParams(-2, -2)
            cp.bottomMargin = dp(10)
            emp.addView(chip, cp)
        }
        msgs.addView(emp)

        val bar = LinearLayout(this)
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setPadding(dp(12), dp(8), dp(12), dp(12))
        val et = EditText(this)
        et.hint = "Ask Friday…"
        et.setHintTextColor(C.dim)
        et.setTextColor(C.text)
        et.textSize = 15f
        et.background = shape(C.card, 24, C.line)
        et.setPadding(dp(18), dp(12), dp(18), dp(12))
        et.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        et.imeOptions = EditorInfo.IME_ACTION_SEND
        et.setOnEditorActionListener { _, id, _ ->
            if (id == EditorInfo.IME_ACTION_SEND) { send(et.text.toString()); true } else false
        }
        val mic = label("🎙", 20f, C.text)
        mic.gravity = Gravity.CENTER
        mic.background = shape(C.card, 22, C.line)
        mic.setOnClickListener { listen() }
        val go = label("↑", 22f, C.onAccent, true)
        go.gravity = Gravity.CENTER
        go.background = shape(C.accent, 22)
        go.setOnClickListener { send(et.text.toString()) }
        bar.addView(et, LinearLayout.LayoutParams(0, -2, 1f))
        val mp = LinearLayout.LayoutParams(dp(44), dp(44))
        mp.leftMargin = dp(8)
        bar.addView(mic, mp)
        val gp = LinearLayout.LayoutParams(dp(44), dp(44))
        gp.leftMargin = dp(8)
        bar.addView(go, gp)
        page.addView(bar)

        list = msgs; scroll = sc; empty = emp; input = et; statusText = st; statusDot = dot
        root.removeAllViews()
        root.addView(page, FrameLayout.LayoutParams(-1, -1))
    }

    private fun setStatus(t: String, color: Int) {
        statusText?.text = t
        statusDot?.background = shape(color, 4)
    }

    private fun addMsg(t: String, user: Boolean) {
        val l = list ?: return
        empty?.let { l.removeView(it); empty = null }
        val tv = label(t, 15f, if (user) C.onAccent else C.text)
        tv.maxWidth = (resources.displayMetrics.widthPixels * 0.78).toInt()
        tv.background = shape(if (user) C.accent else C.card, 18, if (user) 0 else C.line)
        tv.setPadding(dp(14), dp(10), dp(14), dp(10))
        val lp = LinearLayout.LayoutParams(-2, -2)
        lp.gravity = if (user) Gravity.END else Gravity.START
        lp.bottomMargin = dp(10)
        l.addView(tv, lp)
        scroll?.post { scroll?.fullScroll(View.FOCUS_DOWN) }
    }

    private fun listen() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
            return
        }
        setStatus("Listening…", C.accent)
        voice.listen()
        statusText?.postDelayed({ if (!busy) setStatus("Ready", C.ok) }, 9000)
    }

    private fun send(t: String) {
        val text = t.trim()
        if (text.isEmpty() || busy) return
        busy = true
        addMsg(text, true)
        input?.setText("")
        setStatus("Thinking…", C.accent)
        Thread {
            try {
                agent.run(text)
            } catch (e: Exception) {
                runOnUiThread { addMsg("Sorry, something went wrong: ${e.message}", false) }
            }
            runOnUiThread { busy = false; setStatus("Ready", C.ok) }
        }.start()
    }
}
