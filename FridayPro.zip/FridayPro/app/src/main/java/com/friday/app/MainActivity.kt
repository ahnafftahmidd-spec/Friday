package com.friday.app
import android.Manifest
import android.app.Activity
import android.app.ActivityManager
import android.app.AlertDialog
import android.app.TimePickerDialog
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.widget.*

class MainActivity : Activity() {
    private class Step(val badge: TextView, val sub: TextView, val bar: ProgressBar, val btn: TextView)

    private val allPerms = arrayOf(Manifest.permission.RECORD_AUDIO, "android.permission.READ_CONTACTS",
        "android.permission.CALL_PHONE", "android.permission.SEND_SMS", "android.permission.POST_NOTIFICATIONS")
    private val navItems = listOf("💬" to "Chat", "🧰" to "Tools", "🧠" to "Memory", "⚙️" to "Settings")
    private val navViews = mutableListOf<TextView>()

    private lateinit var frame: FrameLayout
    private lateinit var content: FrameLayout
    private var onMain = false
    private var tab = 0
    private var downloading = false
    private var camUri: Uri? = null

    private var sModel: Step? = null
    private var sPerm: Step? = null
    private var sAcc: Step? = null
    private var startBtn: TextView? = null

    private var list: LinearLayout? = null
    private var scroll: ScrollView? = null
    private var empty: View? = null
    private var input: EditText? = null
    private var statusText: TextView? = null
    private var statusDot: View? = null

    private val hook: (String, Boolean) -> Unit = { t, u -> runOnUiThread { if (tab == 0 && list != null) addMsg(t, u) } }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = C.bg
        window.navigationBarColor = C.bg
        frame = FrameLayout(this)
        frame.setBackgroundColor(C.bg)
        frame.fitsSystemWindows = true
        setContentView(frame)
        if (Core.brain.available) showMain() else showSetup()
    }

    override fun onStart() { super.onStart(); Core.listeners.add(hook) }
    override fun onStop() { Core.listeners.remove(hook); super.onStop() }
    override fun onResume() {
        super.onResume()
        if (!onMain) refreshSetup() else if (tab == 3) switchTab(3)
    }

    private fun has(p: String) = checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED
    private fun readyText() = if (Core.prefs.getBoolean("wake", false)) "Ready · “Hey Friday” is on" else "Ready"

    // ================= Setup =================

    private fun addStep(parent: LinearLayout, n: String, title: String, sub: String, withBar: Boolean, action: String): Step {
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.background = shape(C.card, 18, C.line)
        card.setPadding(dp(16), dp(16), dp(16), dp(16))
        val top = LinearLayout(this)
        top.gravity = Gravity.CENTER_VERTICAL
        val badge = label(n, 14f, C.text, true)
        badge.gravity = Gravity.CENTER
        badge.background = shape(C.line, 14)
        top.addView(badge, LinearLayout.LayoutParams(dp(28), dp(28)))
        val tcol = LinearLayout(this)
        tcol.orientation = LinearLayout.VERTICAL
        tcol.setPadding(dp(14), 0, 0, 0)
        tcol.addView(label(title, 16f, C.text, true))
        val s = label(sub, 13f, C.dim)
        tcol.addView(s)
        top.addView(tcol, LinearLayout.LayoutParams(0, -2, 1f))
        card.addView(top)
        val bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
        bar.max = 1000
        bar.progressTintList = ColorStateList.valueOf(C.accent)
        bar.progressBackgroundTintList = ColorStateList.valueOf(C.line)
        bar.visibility = if (withBar) View.VISIBLE else View.GONE
        val bp = LinearLayout.LayoutParams(-1, dp(6))
        bp.topMargin = dp(14)
        card.addView(bar, bp)
        val btn = pill(action, false)
        btn.visibility = View.GONE
        val kp = LinearLayout.LayoutParams(-2, -2)
        kp.topMargin = dp(12)
        card.addView(btn, kp)
        val cp = LinearLayout.LayoutParams(-1, -2)
        cp.bottomMargin = dp(12)
        parent.addView(card, cp)
        return Step(badge, s, bar, btn)
    }

    private fun showSetup() {
        onMain = false
        val page = LinearLayout(this)
        page.orientation = LinearLayout.VERTICAL
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(22), dp(30), dp(22), dp(12))
        val logo = ImageView(this)
        logo.setImageResource(R.mipmap.ic_launcher)
        col.addView(logo, LinearLayout.LayoutParams(dp(60), dp(60)))
        val h = label("Welcome to Friday", 28f, C.text, true)
        h.setPadding(0, dp(18), 0, 0)
        col.addView(h)
        val sub = label("Your private AI assistant. It thinks on this phone, so your conversations stay with you.", 15f, C.dim)
        sub.setPadding(0, dp(6), 0, dp(24))
        col.addView(sub)
        val m = addStep(col, "1", "AI model", "Preparing…", true, "Retry")
        val pm = addStep(col, "2", "Permissions", "Microphone, contacts, calls, texts and notifications, so Friday can act for you.", false, "Grant permissions")
        val acc = addStep(col, "3", "Phone control", "Lets Friday open apps, tap and read the screen. In Settings find Friday under Installed or Downloaded apps and switch it on.", false, "Open settings")
        sModel = m; sPerm = pm; sAcc = acc
        m.btn.setOnClickListener { startDownload() }
        pm.btn.setOnClickListener { requestPermissions(allPerms, 1) }
        acc.btn.setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        val start = pill("Start using Friday", true)
        start.alpha = 0.4f
        start.isEnabled = false
        start.setOnClickListener { showMain() }
        startBtn = start
        val sv = ScrollView(this)
        sv.isVerticalScrollBarEnabled = false
        sv.addView(col)
        page.addView(sv, LinearLayout.LayoutParams(-1, 0, 1f))
        val sp = LinearLayout.LayoutParams(-1, -2)
        sp.setMargins(dp(22), dp(8), dp(22), dp(18))
        page.addView(start, sp)
        frame.removeAllViews()
        frame.addView(page, FrameLayout.LayoutParams(-1, -1))
        refreshSetup()
        if (!has(Manifest.permission.RECORD_AUDIO)) requestPermissions(allPerms, 1)
        if (Core.brain.available) markModelDone() else startDownload()
    }

    private fun mark(s: Step, done: Boolean, doneText: String) {
        if (done) {
            s.badge.text = "✓"
            s.badge.background = shape(C.ok, 14)
            s.badge.setTextColor(0xFF08210F.toInt())
            s.sub.text = doneText
            s.btn.visibility = View.GONE
        } else s.btn.visibility = View.VISIBLE
    }

    private fun refreshSetup() {
        sPerm?.let { mark(it, has(Manifest.permission.RECORD_AUDIO), "Permissions granted.") }
        sAcc?.let { mark(it, FridayService.i != null, "Phone control is on.") }
    }

    private fun markModelDone() {
        val m = sModel ?: return
        m.bar.visibility = View.GONE
        mark(m, true, "Ready. Runs offline on your phone.")
        startBtn?.let { it.alpha = 1f; it.isEnabled = true }
    }

    private fun startDownload() {
        val m = sModel ?: return
        if (downloading) return
        downloading = true
        val model = Core.model()
        m.sub.text = "Downloading ${model.name} (about ${model.mb} MB). Keep this screen open, Wi-Fi recommended."
        m.btn.visibility = View.GONE
        m.bar.visibility = View.VISIBLE
        m.bar.progress = 0
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        Thread {
            val url = if (model.url.isNotEmpty()) model.url else (Hf.resolve(model.repo) ?: "")
            val r: Result<Unit> = if (url.isEmpty()) Result.failure(java.io.IOException("Couldn't find the model file online"))
            else Downloader(Core.brain.fileFor(model)).run(url) { done, total ->
                runOnUiThread {
                    if (total > 0) m.bar.progress = (done * 1000 / total).toInt()
                    m.sub.text = "Downloading ${model.name} · ${done / 1_000_000} of ${total / 1_000_000} MB"
                }
            }
            runOnUiThread {
                downloading = false
                window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                if (r.isSuccess) markModelDone() else {
                    m.bar.visibility = View.GONE
                    m.sub.text = "Download stopped: ${r.exceptionOrNull()?.message}. Check your connection and tap Retry. It will resume."
                    m.btn.visibility = View.VISIBLE
                }
            }
        }.start()
    }

    // ================= Main shell =================

    private fun showMain() {
        onMain = true
        Thread { Core.brain.warm() }.start()
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        content = FrameLayout(this)
        col.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))
        val line = View(this)
        line.setBackgroundColor(C.line)
        col.addView(line, LinearLayout.LayoutParams(-1, dp(1)))
        val nav = LinearLayout(this)
        navViews.clear()
        navItems.forEachIndexed { i, p ->
            val v = label(p.first + "\n" + p.second, 11f, C.dim)
            v.gravity = Gravity.CENTER
            v.setPadding(0, dp(8), 0, dp(8))
            v.setOnClickListener { switchTab(i) }
            nav.addView(v, LinearLayout.LayoutParams(0, -2, 1f))
            navViews.add(v)
        }
        col.addView(nav)
        frame.removeAllViews()
        frame.addView(col, FrameLayout.LayoutParams(-1, -1))
        switchTab(0)
        if (Core.prefs.getBoolean("wake", false) && has(Manifest.permission.RECORD_AUDIO)) startWake()
    }

    private fun switchTab(i: Int) {
        tab = i
        list = null; scroll = null; empty = null; input = null; statusText = null; statusDot = null
        content.removeAllViews()
        val page = when (i) { 0 -> chatPage(); 1 -> toolsPage(); 2 -> memoryPage(); else -> settingsPage() }
        content.addView(page, FrameLayout.LayoutParams(-1, -1))
        navViews.forEachIndexed { k, v -> v.setTextColor(if (k == i) C.accent else C.dim) }
    }

    private fun header(title: String, sub: String): View {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(dp(20), dp(20), dp(20), dp(8))
        c.addView(label(title, 26f, C.text, true))
        c.addView(label(sub, 13f, C.dim))
        return c
    }

    private fun ask(title: String, hint1: String, hint2: String?, cb: (String, String) -> Unit) {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(8), dp(20), 0)
        val a = EditText(this); a.hint = hint1
        box.addView(a)
        var b: EditText? = null
        if (hint2 != null) { val e = EditText(this); e.hint = hint2; box.addView(e); b = e }
        AlertDialog.Builder(this).setTitle(title).setView(box)
            .setPositiveButton("OK") { _, _ -> cb(a.text.toString().trim(), b?.text?.toString()?.trim() ?: "") }
            .setNegativeButton("Cancel", null).show()
    }

    private fun runCmd(t: String) { switchTab(0); send(t) }

    // ================= Chat =================

    private fun chatPage(): View {
        val page = LinearLayout(this)
        page.orientation = LinearLayout.VERTICAL
        val head = LinearLayout(this)
        head.gravity = Gravity.CENTER_VERTICAL
        head.setPadding(dp(18), dp(14), dp(18), dp(14))
        val logo = ImageView(this)
        logo.setImageResource(R.mipmap.ic_launcher)
        head.addView(logo, LinearLayout.LayoutParams(dp(38), dp(38)))
        val hc = LinearLayout(this)
        hc.orientation = LinearLayout.VERTICAL
        hc.setPadding(dp(12), 0, 0, 0)
        hc.addView(label("Friday", 18f, C.text, true))
        val srow = LinearLayout(this)
        srow.gravity = Gravity.CENTER_VERTICAL
        val dot = View(this)
        dot.background = shape(C.ok, 4)
        srow.addView(dot, LinearLayout.LayoutParams(dp(8), dp(8)))
        val st = label(readyText(), 12f, C.dim)
        st.setPadding(dp(6), 0, 0, 0)
        srow.addView(st)
        hc.addView(srow)
        head.addView(hc, LinearLayout.LayoutParams(0, -2, 1f))
        page.addView(head)
        val div = View(this)
        div.setBackgroundColor(C.line)
        page.addView(div, LinearLayout.LayoutParams(-1, dp(1)))

        val msgs = LinearLayout(this)
        msgs.orientation = LinearLayout.VERTICAL
        msgs.setPadding(dp(14), dp(14), dp(14), dp(14))
        val sc = ScrollView(this)
        sc.isVerticalScrollBarEnabled = false
        sc.addView(msgs)
        page.addView(sc, LinearLayout.LayoutParams(-1, 0, 1f))

        val emp = LinearLayout(this)
        emp.orientation = LinearLayout.VERTICAL
        emp.gravity = Gravity.CENTER_HORIZONTAL
        emp.setPadding(0, dp(36), 0, 0)
        emp.addView(label("How can I help?", 24f, C.text, true))
        val es = label("Ask anything, or tell me to call, text, set alarms, search the web or control your phone.", 14f, C.dim)
        es.gravity = Gravity.CENTER
        es.setPadding(dp(20), dp(8), dp(20), dp(20))
        emp.addView(es)
        for (s in listOf("What can you do?", "Set a timer for 5 minutes", "Search for today's top news", "What's on my screen?")) {
            val chip = pill(s, false)
            chip.setOnClickListener { send(s) }
            val cp = LinearLayout.LayoutParams(-2, -2)
            cp.bottomMargin = dp(10)
            emp.addView(chip, cp)
        }
        list = msgs; scroll = sc; statusText = st; statusDot = dot
        val h = Core.mem.recent(40)
        if (h.isEmpty()) { msgs.addView(emp); empty = emp } else h.forEach { addMsg(it.second, it.first) }

        val bar = LinearLayout(this)
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setPadding(dp(12), dp(8), dp(12), dp(12))
        val et = EditText(this)
        et.hint = "Ask Friday…"
        et.setHintTextColor(C.dim)
        et.setTextColor(C.text)
        et.textSize = 15f
        et.background = shape(C.card, 24, C.line)
        et.setPadding(dp(18), dp(12), dp(18), dp(12))
        et.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        et.imeOptions = EditorInfo.IME_ACTION_SEND
        et.setOnEditorActionListener { _, id, _ ->
            if (id == EditorInfo.IME_ACTION_SEND) { send(et.text.toString()); et.setText(""); true } else false
        }
        val mic = label("🎙", 20f, C.text)
        mic.gravity = Gravity.CENTER
        mic.background = shape(C.card, 22, C.line)
        mic.setOnClickListener { listen() }
        val go = label("↑", 22f, C.onAccent, true)
        go.gravity = Gravity.CENTER
        go.background = shape(C.accent, 22)
        go.setOnClickListener { send(et.text.toString()); et.setText("") }
        bar.addView(et, LinearLayout.LayoutParams(0, -2, 1f))
        val mp = LinearLayout.LayoutParams(dp(44), dp(44))
        mp.leftMargin = dp(8)
        bar.addView(mic, mp)
        val gp = LinearLayout.LayoutParams(dp(44), dp(44))
        gp.leftMargin = dp(8)
        bar.addView(go, gp)
        page.addView(bar)
        input = et
        return page
    }

    private fun setStatus(t: String, color: Int) {
        statusText?.text = t
        statusDot?.background = shape(color, 4)
    }

    private fun addMsg(t: String, user: Boolean) {
        val l = list ?: return
        empty?.let { l.removeView(it); empty = null }
        val tv = label(t, 15f, if (user) C.onAccent else C.text)
        tv.maxWidth = (resources.displayMetrics.widthPixels * 0.78).toInt()
        tv.background = shape(if (user) C.accent else C.card, 18, if (user) 0 else C.line)
        tv.setPadding(dp(14), dp(10), dp(14), dp(10))
        val lp = LinearLayout.LayoutParams(-2, -2)
        lp.gravity = if (user) Gravity.END else Gravity.START
        lp.bottomMargin = dp(10)
        l.addView(tv, lp)
        scroll?.post { scroll?.fullScroll(View.FOCUS_DOWN) }
    }

    private fun listen() {
        if (!has(Manifest.permission.RECORD_AUDIO)) { requestPermissions(allPerms, 1); return }
        setStatus("Listening…", C.accent)
        Ears.once(this, { heard -> send(heard) }, { setStatus(readyText(), C.ok) })
    }

    private fun send(t: String) {
        val text = t.trim()
        if (text.isEmpty() || Core.working) return
        setStatus("Thinking…", C.accent)
        Thread {
            Core.handle(text)
            runOnUiThread { setStatus(readyText(), C.ok) }
        }.start()
    }

    // ================= Tools =================

    private fun card(emoji: String, title: String, sub: String, act: () -> Unit): View {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.background = shape(C.card, 18, C.line)
        c.setPadding(dp(16), dp(16), dp(16), dp(16))
        c.addView(label(emoji, 26f, C.text))
        val t = label(title, 15f, C.text, true)
        t.setPadding(0, dp(8), 0, 0)
        c.addView(t)
        c.addView(label(sub, 12f, C.dim))
        c.setOnClickListener { act() }
        return c
    }

    private fun toolsPage(): View {
        val page = LinearLayout(this)
        page.orientation = LinearLayout.VERTICAL
        page.addView(header("Tools", "Tap a tool, or just ask in chat."))
        val grid = LinearLayout(this)
        grid.orientation = LinearLayout.VERTICAL
        grid.setPadding(dp(14), dp(8), dp(14), dp(14))
        val items = listOf<View>(
            card("📞", "Call", "Ring a contact") { ask("Call whom?", "Name or number", null) { a, _ -> runCmd("call $a") } },
            card("💬", "Text", "Send an SMS") { ask("Send a text", "To (name or number)", "Message") { a, b -> runCmd("text $a saying $b") } },
            card("⏰", "Alarm", "Pick a time") {
                TimePickerDialog(this, { _, h, m -> runCmd("set alarm for $h:" + m.toString().padStart(2, '0')) }, 7, 0, false).show()
            },
            card("⏱", "Timer", "Count down") { ask("Timer", "Minutes", null) { a, _ -> runCmd("set a timer for $a minutes") } },
            card("🌐", "Web search", "Ask the internet") { ask("Search the web", "What do you want to know?", null) { a, _ -> runCmd("search for $a") } },
            card("📄", "Read a page", "Summarize a link") { ask("Summarize a page", "https://…", null) { a, _ -> runCmd("summarize $a") } },
            card("📷", "Camera", "Snap and describe") { openCamera() },
            card("🖼", "Image", "Pick from gallery") { pickImage() },
            card("👁", "Read screen", "Explain what's showing") { runCmd("what's on my screen") },
            card("📱", "Open app", "Launch by name") { ask("Open app", "App name", null) { a, _ -> runCmd("open $a") } },
            card("🧠", "Memory", "Things I remember") { switchTab(2) },
            card("⚙️", "Settings", "Wake word, voice…") { switchTab(3) }
        )
        var i = 0
        while (i < items.size) {
            val row = LinearLayout(this)
            for (k in 0..1) {
                val lp = LinearLayout.LayoutParams(0, -2, 1f)
                lp.setMargins(dp(6), dp(6), dp(6), dp(6))
                row.addView(items[i + k], lp)
            }
            grid.addView(row)
            i += 2
        }
        val sv = ScrollView(this)
        sv.isVerticalScrollBarEnabled = false
        sv.addView(grid)
        page.addView(sv, LinearLayout.LayoutParams(-1, 0, 1f))
        return page
    }

    private fun openCamera() {
        val v = ContentValues()
        v.put(MediaStore.Images.Media.DISPLAY_NAME, "friday_" + System.currentTimeMillis() + ".jpg")
        v.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
        camUri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v)
        val i = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        i.putExtra(MediaStore.EXTRA_OUTPUT, camUri)
        try { startActivityForResult(i, 11) } catch (e: Exception) { Toast.makeText(this, "No camera app found", Toast.LENGTH_SHORT).show() }
    }

    private fun pickImage() {
        val i = Intent(Intent.ACTION_GET_CONTENT)
        i.type = "image/*"
        startActivityForResult(i, 12)
    }

    override fun onActivityResult(rc: Int, res: Int, d: Intent?) {
        super.onActivityResult(rc, res, d)
        var uri: Uri? = null
        if (rc == 11) {
            if (res != RESULT_OK) { camUri?.let { contentResolver.delete(it, null, null) }; return }
            uri = camUri
        }
        if (rc == 12 && res == RESULT_OK) uri = d?.data
        val u = uri ?: return
        switchTab(0)
        setStatus("Looking at the image…", C.accent)
        Thread {
            val o = BitmapFactory.Options()
            o.inSampleSize = 2
            val bmp = try { contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, o) } } catch (e: Exception) { null }
            if (bmp == null) runOnUiThread { addMsg("I couldn't open that image.", false) } else Core.describe(bmp)
            runOnUiThread { setStatus(readyText(), C.ok) }
        }.start()
    }

    // ================= Memory =================

    private fun memoryPage(): View {
        val page = LinearLayout(this)
        page.orientation = LinearLayout.VERTICAL
        val notes = Core.mem.notes()
        page.addView(header("Memory", "${notes.size} things I remember. Say “remember that …” anytime."))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16), dp(8), dp(16), dp(16))
        if (notes.isEmpty()) {
            val e = label("Nothing yet. Add a note below, for example “My wife is called Sara”.", 14f, C.dim)
            e.setPadding(dp(4), dp(8), dp(4), dp(8))
            col.addView(e)
        }
        notes.forEachIndexed { idx, n ->
            val row = LinearLayout(this)
            row.gravity = Gravity.CENTER_VERTICAL
            row.background = shape(C.card, 14, C.line)
            row.setPadding(dp(14), dp(12), dp(14), dp(12))
            row.addView(label(n, 14f, C.text), LinearLayout.LayoutParams(0, -2, 1f))
            val x = label("✕", 16f, C.dim)
            x.setPadding(dp(12), 0, 0, 0)
            x.setOnClickListener { Core.mem.remove(idx); switchTab(2) }
            row.addView(x)
            val lp = LinearLayout.LayoutParams(-1, -2)
            lp.bottomMargin = dp(8)
            col.addView(row, lp)
        }
        val sv = ScrollView(this)
        sv.isVerticalScrollBarEnabled = false
        sv.addView(col)
        page.addView(sv, LinearLayout.LayoutParams(-1, 0, 1f))
        val bar = LinearLayout(this)
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setPadding(dp(12), dp(8), dp(12), dp(12))
        val et = EditText(this)
        et.hint = "Add something to remember…"
        et.setHintTextColor(C.dim)
        et.setTextColor(C.text)
        et.textSize = 15f
        et.background = shape(C.card, 24, C.line)
        et.setPadding(dp(18), dp(12), dp(18), dp(12))
        val add = pill("Add", true)
        add.setOnClickListener { if (et.text.isNotBlank()) { Core.mem.add(et.text.toString()); switchTab(2) } }
        bar.addView(et, LinearLayout.LayoutParams(0, -2, 1f))
        val ap = LinearLayout.LayoutParams(-2, -2)
        ap.leftMargin = dp(8)
        bar.addView(add, ap)
        page.addView(bar)
        return page
    }

    // ================= Settings =================

    private fun row(title: String, sub: String, right: View?): View {
        val r = LinearLayout(this)
        r.gravity = Gravity.CENTER_VERTICAL
        r.background = shape(C.card, 16, C.line)
        r.setPadding(dp(16), dp(14), dp(16), dp(14))
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.addView(label(title, 15f, C.text, true))
        c.addView(label(sub, 12f, C.dim))
        r.addView(c, LinearLayout.LayoutParams(0, -2, 1f))
        if (right != null) r.addView(right)
        return r
    }

    private fun settingsPage(): View {
        val page = LinearLayout(this)
        page.orientation = LinearLayout.VERTICAL
        page.addView(header("Settings", "Make Friday yours."))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16), dp(8), dp(16), dp(20))
        fun add(v: View) { val lp = LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = dp(10); col.addView(v, lp) }

        val wake = Switch(this)
        wake.isChecked = Core.prefs.getBoolean("wake", false)
        wake.setOnCheckedChangeListener { _, on ->
            if (on && !has(Manifest.permission.RECORD_AUDIO)) { wake.isChecked = false; requestPermissions(allPerms, 1) }
            else {
                Core.prefs.edit().putBoolean("wake", on).apply()
                if (on) startWake() else stopService(Intent(this, ListenService::class.java))
            }
        }
        add(row("Hey Friday", "Listens in the background. Uses battery and shows a notification.", wake))

        val speak = Switch(this)
        speak.isChecked = Core.prefs.getBoolean("speak", true)
        speak.setOnCheckedChangeListener { _, on -> Core.prefs.edit().putBoolean("speak", on).apply() }
        add(row("Spoken replies", "Friday reads its answers aloud.", speak))

        val perm = pill("Grant", false)
        perm.setOnClickListener { requestPermissions(allPerms, 1) }
        add(row("Permissions", "Mic, contacts, calls, texts, notifications.", perm))

        val acc = pill(if (FridayService.i != null) "On" else "Turn on", false)
        acc.setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        add(row("Phone control", "Tap, type, read the screen, work in the background.", acc))

        val model = pill("Change", false)
        model.setOnClickListener {
            val names = arrayOf("Small · Qwen2.5 0.5B · fastest, ~0.5 GB", "Standard · Qwen2.5 1.5B · balanced, ~1.6 GB", "Large · Qwen3 4B · smartest but slower, ~2.4 GB, needs about 8 GB RAM")
            val cur = MODELS.indexOfFirst { it.key == Core.model().key }
            AlertDialog.Builder(this).setTitle("Choose AI model").setSingleChoiceItems(names, cur) { d, which ->
                Core.prefs.edit().putString("model", MODELS[which].key).apply()
                d.dismiss()
                if (Core.brain.available) switchTab(3) else showSetup()
            }.setNeutralButton("Re-download current") { _, _ ->
                Core.brain.active().delete()
                java.io.File(Core.brain.active().path + ".part").delete()
                showSetup()
            }.setNegativeButton("Close", null).show()
        }
        add(row("AI model", Core.model().name + " · runs on this phone", model))

        val clr = pill("Clear", false)
        clr.setOnClickListener { Core.mem.clearLog(); switchTab(3); Toast.makeText(this, "Chat history cleared", Toast.LENGTH_SHORT).show() }
        add(row("Chat history", "Delete saved conversations. Notes are kept.", clr))

        val sv = ScrollView(this)
        sv.isVerticalScrollBarEnabled = false
        sv.addView(col)
        page.addView(sv, LinearLayout.LayoutParams(-1, 0, 1f))
        return page
    }

    private fun startWake() {
        try { startForegroundService(Intent(this, ListenService::class.java)) }
        catch (e: Exception) { Toast.makeText(this, "Couldn't start listening: ${e.message}", Toast.LENGTH_LONG).show() }
    }
}
