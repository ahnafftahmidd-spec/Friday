package com.friday.app
import android.content.Context
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.widget.TextView

object C {
    val bg = 0xFF0E0D12.toInt()
    val card = 0xFF1A1820.toInt()
    val line = 0xFF2A2733.toInt()
    val text = 0xFFF3EEF8.toInt()
    val dim = 0xFF9B93A8.toInt()
    val accent = 0xFFC96BE6.toInt()
    val onAccent = 0xFF1A0B22.toInt()
    val ok = 0xFF4ADE80.toInt()
}

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

fun Context.shape(color: Int, radiusDp: Int, stroke: Int = 0): GradientDrawable {
    val g = GradientDrawable()
    g.setColor(color)
    g.cornerRadius = dp(radiusDp).toFloat()
    if (stroke != 0) g.setStroke(dp(1), stroke)
    return g
}

fun Context.label(t: String, sp: Float, color: Int, bold: Boolean = false): TextView {
    val v = TextView(this)
    v.text = t; v.textSize = sp; v.setTextColor(color)
    if (bold) v.setTypeface(v.typeface, Typeface.BOLD)
    return v
}

fun Context.pill(t: String, filled: Boolean): TextView {
    val v = label(t, 14f, if (filled) C.onAccent else C.text, true)
    v.gravity = Gravity.CENTER
    v.background = shape(if (filled) C.accent else C.card, 20, if (filled) 0 else C.line)
    v.setPadding(dp(18), dp(12), dp(18), dp(12))
    return v
}
