# Friday
Private on-device AI assistant. First launch downloads its own Qwen model and walks you through setup.
Build: upload FridayPro.zip to GitHub (same name replaces the old one); Actions builds app-debug.apk.
