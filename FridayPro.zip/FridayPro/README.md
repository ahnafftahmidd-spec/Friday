# Friday
On first launch the app downloads its own Qwen model and walks you through setup.
Build: upload FridayPro.zip + .github/workflows/build.yml to GitHub; Actions builds app-debug.apk.
